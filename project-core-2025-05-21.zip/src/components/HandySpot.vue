<template>
  <RefreshLandData />
</template>

<script setup>
import RefreshLandData from '@/components/RefreshLandData.vue'
</script>
